class HttpClient {
    static async fetch(url, opts = {}, customOpts = {}) {
        const res = await fetch(url, opts);

        if (customOpts.redirectMeansError && res.redirected) {
            throw new Error('Unexpected redirect');
        }

        if (!res.ok) {
            throw new Error(`${res.status} ${res.statusText}`);
        }

        return res;
    }
}

module.exports = HttpClient;
