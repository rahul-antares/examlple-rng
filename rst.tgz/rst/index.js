#!/bin/env node

const colors       = require('colors');
// const { program }  = require('commander');
const Execute      = require ('./exec');

// function myParseInt(value) {
//     const parsedValue = parseInt(value, 10);
//     if (isNaN(parsedValue)) {
//         throw new program.InvalidArgumentError('Not a number.');
//     }
//     return parsedValue;
// }
//
// program
//     .showHelpAfterError()
//     .requiredOption('-u, --username <name>', 'User Name')
//     .requiredOption('-p, --password <name>', 'Password')
//     .requiredOption('-a, --auth-host <name>', 'Auth Host Name/IP')
//     .requiredOption('-r, --rgs-host <name>', 'RGS Host Name/IP')
//     .option('-e, --env-var-name <name>', 'Name of the env variable storing the Auth Client ID', 'AUTH_CLIENT_ID')
//     .option('-h, --http-proto <name>', 'http or https', 'https')
// ;

// program.parse (process.argv);
// const options = program.opts ();

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
process.removeAllListeners('warning');
async function main() {
    try {
        await Execute ({});
    } catch (error) {
        console.error (colors.red("ERROR:"), error);
    }
}

main();
