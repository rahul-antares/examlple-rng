const Config     = require ('./config');
const HttpClient = require ('./http-client');

async function auth () {
    try {
        const { host, clientId, username, password } = Config.auth;
        const authURL = `https://${host}/auth/token/oauth2`;
        const res = await HttpClient.fetch (
            authURL,
            {
                method: "POST",
                headers: {
                    "Content-Type" : "application/json",
                    "Accept"       : "application/json",
                },
                body: JSON.stringify({
                    "client_id"  : clientId,
                    "username"   : username,
                    "password"   : password,
                    "grant_type" : "password"
                })
            },
            // custom options
            { redirectMeansError: true }
        );

        console.log ('res === ', res)

        return res.json ();
    } catch (err) {
        throw err;
    }
}

async function init () {
    try {
        const initParams = Config.params.init;

    } catch (err) {
        throw err;
    }
}

async function play () {
    try {
        const playParams = Config.params.play;

    } catch (err) {
        throw err;
    }
}

async function next () {
    try {
        const nextParams = Config.params.next;

    } catch (err) {
        throw err;
    }
}

async function finish () {
    try {
        const finishParams = Config.params.finish;

    } catch (err) {
        throw err;
    }
}

async function extraSpin () {
    try {
        const extraSpinParams = Config.params.extraSpin;

    } catch (err) {
        throw err;
    }
}

module.exports = {
    auth, init, play,
    next, finish, extraSpin
};
