require ('dotenv').config();

const networkConf = {
    username    : process.env.UserName,
    password    : process.env.Password,
    authClientId: process.env.AuthClientId,
    authHost    : process.env.AuthHost,
    rGSHost     : process.env.RGSHost,
};

const rgsConf = {
    jurisdiction: process.env.Jurisdiction,
    partnerId   : process.env.PartnerId,
    locale      : process.env.Locale,
};

const gameNBetConf = {
    gameId    :   process.env.GameId,
    betAmount :   process.env.BetAmount ,
    buyFeature:   process.env.BuyFeature,
    featureMod:   process.env.FeatureMod,
    moneyMode :   process.env.MoneyMode ,
    cheats    : process.env.PlayCheats,
};

const gambleConf = {
    maxLevelToGamble: process.env.MaxLevelToGamble,
};

const Config = {
    auth: {
        host:     networkConf.authHost,
        clientId: networkConf.authClientId,
        username: networkConf.username,
        password: networkConf.password,
    },

    init: {

    },

    play: {

    },

    next: {

    },

    extraSpin: {

    },

    finish: {

    },
};

module.exports = Config;
