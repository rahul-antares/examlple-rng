const Actions = require ('./actions');

async function Execute (options) {
    try {
        const res = await Actions.auth ();
        console.log ("Auth resp = ", res);

        // await Actions.init ();
        // await Actions.play ();
        // await Actions.next ();
        // await Actions.extraSpin ();
        // await Actions.finish ();
    } catch (err) {
        throw err;
    }
}

module.exports = Execute;
